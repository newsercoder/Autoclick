# Auto Tap Restart (Android / Kotlin)

This is a starter Android Studio project for an original auto-tap utility. It does not contain or copy the proprietary source code/assets of True Developers Studio's app.

## Included in this MVP
- Kotlin Android app, min Android 7.0 (API 24).
- User-configurable tap interval.
- Floating Start/Stop controls.
- AccessibilityService gesture dispatch.
- Configurable session timer that resets the tap session timer after N minutes while continuing the run.

## Build
1. Open this folder in Android Studio (recent version with Android Gradle Plugin 8.6.1 support).
2. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK output is normally `app/build/outputs/apk/debug/app-debug.apk`.

## First run
1. Open the app and set the tap interval and restart interval. `0` disables the restart timer.
2. Grant **Display over other apps** permission.
3. Open Android Accessibility settings and enable **Auto Tap Restart Service**.
4. Return to the app. Use the floating Start/Stop controls.

## Important limitations of this starter
- Current tap target is the center of the screen; this is not yet the original app's full multi-target editor, swipe editor, profile manager, or exact UI.
- “Auto restart” currently starts a fresh timed session after the configured interval while continuing the tap loop. It does not relaunch an app killed by Android or reboot the phone.
- Android/OEM battery restrictions may stop background services. Do not use this for bypassing app protections or automating actions that violate another service's rules.
- Test only on apps/devices where you have permission to automate input.

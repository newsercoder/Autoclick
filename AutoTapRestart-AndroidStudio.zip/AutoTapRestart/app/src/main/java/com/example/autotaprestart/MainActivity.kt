package com.example.autotaprestart

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF7F8FC.toInt())
        }
        root.addView(TextView(this).apply {
            text = "AUTO TAP RESTART"
            textSize = 23f
            setTextColor(0xFF17213A.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Bản thử nghiệm – chạm tự động tại tâm màn hình"
            textSize = 14f
            setPadding(0, 8, 0, 20)
        })

        val tapInput = numberInput("Khoảng cách giữa các lần chạm (ms)", prefs.getLong("tap_ms", 500).toString())
        val restartInput = numberInput("Tự khởi động lại sau (phút, 0 = tắt)", prefs.getLong("restart_min", 60).toString())
        root.addView(tapInput.first); root.addView(tapInput.second)
        root.addView(restartInput.first); root.addView(restartInput.second)

        val save = Button(this).apply {
            text = "LƯU CÀI ĐẶT"
            setOnClickListener {
                val tap = tapInput.second.text.toString().toLongOrNull()?.coerceAtLeast(100) ?: 500
                val restart = restartInput.second.text.toString().toLongOrNull()?.coerceAtLeast(0) ?: 60
                prefs.edit().putLong("tap_ms", tap).putLong("restart_min", restart).apply()
                Toast.makeText(this@MainActivity, "Đã lưu cài đặt", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(save, matchWrap())

        val overlay = Button(this).apply {
            text = "CẤP QUYỀN HIỂN THỊ NÚT NỔI"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Đã có quyền nút nổi", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(overlay, matchWrap())

        val accessibility = Button(this).apply {
            text = "BẬT DỊCH VỤ AUTO TAP"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(accessibility, matchWrap())
        root.addView(TextView(this).apply {
            text = "Sau khi bật dịch vụ Trợ năng và quyền hiển thị trên ứng dụng khác, quay lại đây. Nút nổi sẽ xuất hiện để bắt đầu/dừng."
            textSize = 13f
            setPadding(0, 18, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun numberInput(label: String, value: String): Pair<TextView, EditText> {
        val title = TextView(this).apply { text = label; textSize = 15f; setPadding(0, 12, 0, 4) }
        val input = EditText(this).apply {
            setSingleLine(true); inputType = 2; setText(value)
            layoutParams = matchWrap()
        }
        return title to input
    }
    private fun matchWrap() = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}

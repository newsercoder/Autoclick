package com.example.autotaprestart

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.view.accessibility.AccessibilityEvent

class TapAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var windowManager: WindowManager
    private var panel: LinearLayout? = null
    private var running = false
    private var tapCount = 0L
    private var sessionStartedAt = 0L
    private var manuallyStopped = false

    private val restartSession = Runnable {
        if (!manuallyStopped) {
            sessionStartedAt = System.currentTimeMillis()
            tapCount = 0
            running = true
            handler.post(tapLoop)
        }
    }

    private val tapLoop = object : Runnable {
        override fun run() {
            if (!running) return
            val dm = resources.displayMetrics
            val path = Path().apply { moveTo(dm.widthPixels / 2f, dm.heightPixels / 2f) }
            val gesture = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 60))
                .build()
            dispatchGesture(gesture, null, null)
            tapCount++
            val prefs = getSharedPreferences("settings", MODE_PRIVATE)
            val restartMinutes = prefs.getLong("restart_min", 0)
            val elapsed = System.currentTimeMillis() - sessionStartedAt
            if (restartMinutes > 0 && elapsed >= restartMinutes * 60_000L) {
                // End this run, pause briefly, then begin a fresh run automatically.
                running = false
                handler.postDelayed(restartSession, 1_000L)
                return
            }
            handler.postDelayed(this, prefs.getLong("tap_ms", 500).coerceAtLeast(100))
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showFloatingControls()
    }

    private fun showFloatingControls() {
        if (panel != null) return
        val start = Button(this).apply { text = "▶ BẮT ĐẦU"; setOnClickListener { startTapping(this) } }
        val stop = Button(this).apply { text = "■ DỪNG"; setOnClickListener { stopTapping(); text = "■ ĐÃ DỪNG" } }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
            addView(start); addView(stop)
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 24; y = 180 }
        try { windowManager.addView(panel, params) } catch (_: Exception) { panel = null }
    }

    private fun startTapping(button: Button) {
        if (running) return
        manuallyStopped = false
        handler.removeCallbacks(restartSession)
        running = true
        sessionStartedAt = System.currentTimeMillis()
        tapCount = 0
        button.text = "● ĐANG CHẠY"
        handler.removeCallbacks(tapLoop)
        handler.post(tapLoop)
    }

    private fun stopTapping() {
        manuallyStopped = true
        running = false
        handler.removeCallbacks(tapLoop)
        handler.removeCallbacks(restartSession)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() { stopTapping() }

    override fun onDestroy() {
        stopTapping()
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        panel = null
        super.onDestroy()
    }
}
